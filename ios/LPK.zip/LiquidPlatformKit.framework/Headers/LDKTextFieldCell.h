//
//  LDKTextFieldCell.h
//  LDCore
//
//  Created by Bryan Nagle on 12/5/13.
//  Copyright (c) 2013 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LDKTextField;

@interface LDKTextFieldCell : UITableViewCell

@property (strong) LDKTextField *textField;

@end

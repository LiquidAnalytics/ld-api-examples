//
//  LDCHelpViewController.h
//  LiquidDecisions
//
//  Created by Bryan Nagle on 2/25/13.
//  Copyright Everglade Solutions, Inc., d/b/a Liquid Analytics. 2008 2009 2010 2011 2012 2013  All rights reserved
//

#import <UIKit/UIKit.h>

@interface LDCHelpViewController : UIViewController

@property (strong, nonatomic) NSString *currentLayout;

- (void)update;

@end

//
//  LDCSelectLoginAsUserViewController.h
//  LiquidDecisions
//
//  Copyright Everglade Solutions, Inc., d/b/a Liquid Analytics. 2015 All rights reserved
//

#import <UIKit/UIKit.h>

@interface LDCSelectLoginAsUserViewController : UIViewController<UISearchBarDelegate>

@end


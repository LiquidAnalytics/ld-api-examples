//
//  LDCInsightPopSectioHeaderView.h
//  LiquidDecisions
//
//  Created by Bryan Nagle on 5/14/13.
//  Copyright (c) 2013 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDKGreySectionHeaderView : UIView

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

//
//  LDMSearchResultsStatic.h
//  LiquidDataModel
//
//  Created by Marshall Hayden on 7/31/13.
//  Copyright (c) 2013 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LDMSearchResults.h"

@interface LDMSearchResultsStatic : LDMSearchResults <LDMSearchResultsProtocol>

@end

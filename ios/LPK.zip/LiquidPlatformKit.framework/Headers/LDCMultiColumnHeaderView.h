//
//  LDCMultiColumnHeaderView.h
//  LDCore
//
//  Created by Bryan Nagle on 8/29/13.
//  Copyright (c) 2013 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDCMultiColumnHeaderView : UIView

@property (strong) NSArray *titles;

@end

//
//  LDCMultiColumnView.h
//  LiquidDecisions
//
//  Created by Bryan Nagle on 8/27/13.
//  Copyright (c) 2013 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LDCColumnCell;

@interface LDCMultiColumnView : UIView

@property (weak) LDCColumnCell *cell;

@end

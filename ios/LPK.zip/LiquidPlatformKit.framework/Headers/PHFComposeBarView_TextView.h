#import <UIKit/UIKit.h>

@interface PHFComposeBarView_TextView : UITextView
- (void)PHFComposeBarView_setContentOffset:(CGPoint)contentOffset;
@end

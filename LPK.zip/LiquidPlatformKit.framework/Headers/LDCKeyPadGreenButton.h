//
//  LDCKeyPadGreenButton.h
//  LiquidDecisions
//
//  Created by Carson Li on 10/14/12.
//  Copyright Everglade Solutions, Inc., d/b/a Liquid Analytics. 2008 2009 2010 2011 2012 2013  All rights reserved
//

#import "LDCButton.h"

@interface LDCKeyPadGreenButton : LDCButton

@end

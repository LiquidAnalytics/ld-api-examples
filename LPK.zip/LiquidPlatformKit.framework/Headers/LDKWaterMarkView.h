//
//  LDKWaterMarkView.h
//  LDCore
//
//  Created by Bryan Nagle on 3/25/15.
//  Copyright (c) 2015 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDKWaterMarkView : UIView

- (void)offline;
- (void)reportNotDefined;

@end

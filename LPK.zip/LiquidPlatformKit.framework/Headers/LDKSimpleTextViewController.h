//
//  LDKSimpleTextViewController.h
//  LDCore
//
//  Created by CARSON LI on 2015-01-14.
//  Copyright (c) 2015 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDKSimpleTextViewController : UIViewController

@property (strong) NSString *text;

@end

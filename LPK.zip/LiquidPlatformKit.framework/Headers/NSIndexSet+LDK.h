//
//  NSIndexSet+LDK.h
//  LDCore
//
//  Created by Bryan Nagle on 10/2/14.
//  Copyright (c) 2014 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSIndexSet (LDK)

- (NSArray *)indexPathArray;

@end

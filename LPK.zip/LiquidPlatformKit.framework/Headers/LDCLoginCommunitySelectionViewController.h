//
//  LDCLoginCommunitySelectionViewController.h
//  LiquidDecisions
//
//  Created by Eric Johnson on 3/28/13.
//  Copyright (c) 2013 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDCLoginCommunitySelectionViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@end

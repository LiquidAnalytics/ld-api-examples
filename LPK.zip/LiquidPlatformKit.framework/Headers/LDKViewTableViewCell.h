//
//  LDKViewTableViewCell.h
//  LDCore
//
//  Created by Bryan Nagle on 3/14/14.
//  Copyright (c) 2014 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDKViewTableViewCell : UITableViewCell

@property (nonatomic, strong) UIView *view;

@end

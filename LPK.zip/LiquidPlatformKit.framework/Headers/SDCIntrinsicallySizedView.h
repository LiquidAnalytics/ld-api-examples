//
//  SDCIntrinsicallySizedView.h
//  SDCAlertView
//
//  Created by Scott Berrevoets on 3/16/14.
//  Copyright (c) 2014 Scotty Doesn't Code. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SDCIntrinsicallySizedView : UIView

@end

#import <UIKit/UIKit.h>

@interface PHFComposeBarView_Button : UIButton
@end

//
//  LDKBlueSectionHeaderView.h
//  LDCore
//
//  Created by Amar Singh on 03/01/14.
//  Copyright (c) 2014 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDKBlueSectionHeaderView : UIView

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

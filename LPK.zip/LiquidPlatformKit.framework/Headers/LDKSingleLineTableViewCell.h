//
//  LDKSingleLineTableViewCell.h
//  LDCore
//
//  Created by Amar Singh on 06/01/14.
//  Copyright (c) 2014 Liquid Analytics. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LDKSingleLineTableViewCell : UITableViewCell

- (instancetype)initWithReuseIdentifier:(NSString*)reuseIdentifier;

@end

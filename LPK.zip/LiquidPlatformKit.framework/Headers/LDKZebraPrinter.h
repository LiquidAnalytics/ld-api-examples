//
//  LDKZebraPrinter.h
//  LDCore
//
//  Created by CARSON LI on 2015-05-26.
//  Copyright (c) 2015 Liquid Analytics. All rights reserved.
//

#import "LDKPrinter.h"

@interface LDKZebraPrinter : LDKPrinter

@end
